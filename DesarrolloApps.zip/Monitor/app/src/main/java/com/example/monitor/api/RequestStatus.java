package com.example.monitor.api;

public enum RequestStatus {
    LOADING,
    ERROR,
    DONE
}
